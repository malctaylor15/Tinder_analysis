
# THIS FILE IS GENERATED FROM NUMPY SETUP.PY
#
# To compare versions robustly, use `numpy.lib.NumpyVersion`
short_version = '1.15.4'
version = '1.15.4'
full_version = '1.15.4'
git_revision = 'de28edd8f514b82c0524b55f622078d47f479322'
release = True

if not release:
    version = full_version
